=== Custom Login Shortcode ===
Tags: custom login, login, shortcode

== Description ==

Custom Login Shortcode adds a simple shortcode [custom_login] to be used everywhere on your wordpress site.
All it does is it outputs a href attribute for login, logout and account. 

Links, strings to be showed and classes to be used, can be configured within the admin settings page. 

The plugin has also been internationalized and localized (only Danish).

